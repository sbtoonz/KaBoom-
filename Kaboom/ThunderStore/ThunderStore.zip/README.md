﻿# KABOOM!
This mod was requested in the odin+ discord to remove large areas of buildings at once 
in order to use this mod you hold your alt placement key while removing things you can set your alt placement key in the valheim settings menu (it is default to left shift)

when you are removing things you will see a radius display on the ground around your character
this is the radius that will be destroyed if you alt place + middle mouse click to remove

middle mouse clicking to remove should work as normal

the radius is configurable and is sync'd to the server if this mod is being used on a server

this mod is server sync'd and is required to live on the server if you wish to use it on one 

good luck have fun
happy modding

Odin + team
